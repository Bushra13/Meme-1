//
//  ViewController.swift
//  Meme App
//
//  Created by Bushra on 13/11/2018.
//  Copyright © 2018 Bushra Alkhushiban. All rights reserved.
//

import UIKit


struct Meme {
    let Top: String?
    let Botttom: String?
    let originalImage: UIImage?
    let memedImage: UIImage?
}


class ViewController: UIViewController , UIImagePickerControllerDelegate,UINavigationControllerDelegate,UITextFieldDelegate{

    @IBOutlet weak var camera: UIBarButtonItem!
    @IBOutlet weak var imageView: UIImageView!
    @IBOutlet weak var Top: UITextField!
    @IBOutlet weak var Botttom: UITextField!
    @IBOutlet weak var BottomBar: UIToolbar!
    @IBOutlet weak var share: UIBarButtonItem!
    @IBOutlet weak var album: UIBarButtonItem!
    

    override func viewDidLoad() {
        super.viewDidLoad()
        
        setStyle(textField: Top, defaultText: "TOP")
        setStyle(textField: Botttom, defaultText: "BOTTOM")
    }
    
    //setTextFields style
    func setStyle(textField: UITextField, defaultText: String) {
    
        
        let memeTextAttributes:[NSAttributedString.Key: Any] = [
            NSAttributedString.Key(rawValue: NSAttributedString.Key.strokeColor.rawValue) : UIColor.black,
            NSAttributedString.Key(rawValue: NSAttributedString.Key.foregroundColor.rawValue) : UIColor.white,
            NSAttributedString.Key(rawValue: NSAttributedString.Key.font.rawValue) : UIFont(name: "HelveticaNeue-CondensedBlack", size: 32)!,
            NSAttributedString.Key(rawValue: NSAttributedString.Key.strokeWidth.rawValue) : -3.0
        ]
        
        //Text Properties
        textField.defaultTextAttributes = memeTextAttributes
        textField.delegate = self
        textField.textAlignment = .center
        textField.text = defaultText
        
    }
   
    
    override func viewWillAppear(_ animated: Bool) {
        
        super.viewWillAppear(animated)
        
        subscribeToKeyboardNotifications()
        camera.isEnabled = UIImagePickerController.isSourceTypeAvailable(UIImagePickerController.SourceType.camera)
        if imageView.image == nil {
            share.isEnabled = false
        } else {
            share.isEnabled = true
        }
      
      
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        
        super.viewWillDisappear(animated)
        unsubscribeToKeyboardNotifications()
    }
    
   
    
    //keyboard
    
    
    func subscribeToKeyboardNotifications() {
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillShow), name: UIResponder.keyboardWillShowNotification, object: nil)
        
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillHide), name: UIResponder.keyboardWillHideNotification, object: nil)
    }
    
    func unsubscribeToKeyboardNotifications() {
        NotificationCenter.default.removeObserver(self, name: UIResponder.keyboardWillShowNotification, object: nil)
        NotificationCenter.default.removeObserver(self, name: UIResponder.keyboardWillHideNotification, object: nil)
    }
    
    @objc private func keyboardWillShow(_ notification: Notification) {
        if Botttom.isFirstResponder {
            view.frame.origin.y -= getKeyboardHeight(notification)}
    }
    
    
    @objc func keyboardWillHide(notification: Notification){
        if Botttom.isFirstResponder{
            self.view.frame.origin.y = 0
        }
    }
    
    func getKeyboardHeight(_ notification: Notification) -> CGFloat {
        let userInfo = notification.userInfo
        let keyboardSize = userInfo![UIResponder.keyboardFrameEndUserInfoKey] as! NSValue
        return keyboardSize.cgRectValue.height
    }
    
    
    
    //Take picture from camera
    
    @IBAction func camera(_ sender: Any) {
        openImagePicker(.camera)
    }
    
    //Take picture from Album
    
    @IBAction func album(_ sender: Any) {
        
        openImagePicker(.photoLibrary)
    }
    
    //called openImagePicker function
    
    func openImagePicker(_ type: UIImagePickerController.SourceType){
        let picker = UIImagePickerController()
        picker.delegate = self
        picker.sourceType = type
        present(picker, animated: true, completion: nil)
    }
   
    
    //To Share Meme
    
    @IBAction func share(_ sender: Any) {
        let memedImage = generateMemedImage()
        let activityController = UIActivityViewController(activityItems: [memedImage], applicationActivities: nil)
        activityController.completionWithItemsHandler = { activity, success, items, error in
            self.saveMeme()
            self.dismiss(animated: true, completion: nil)
        }
        present(activityController, animated: true, completion: nil)
    }
   
    
    //  save meme
    
    func saveMeme() {
    //Create the meme
    let memedImage = generateMemedImage()
    
        let meme = Meme (Top: Top.text!, Botttom: Botttom.text!,originalImage: imageView.image!, memedImage: memedImage)
    
    }
        
    
   
    //
    
func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
    if let image = info[UIImagePickerController.InfoKey.originalImage] as? UIImage {
        imageView.image = image
        picker.dismiss(animated: true, completion: nil )
        
    }

}
    
    // To cancel
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        picker.dismiss(animated: true, completion: nil)
    }
    
    
    // clear textField
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        if textField.text == "TOP" || textField.text == "BOTTOM" {
            textField.text = ""
        }
        
    }
    
    //return
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        
        return true;
    }
    
//show and hide toolbar
    
    func generateMemedImage() -> UIImage {
        
        hideToolBar(true)
        
        UIGraphicsBeginImageContext(self.view.frame.size)
        view.drawHierarchy(in: self.view.frame, afterScreenUpdates: true)
        let memedImage:UIImage = UIGraphicsGetImageFromCurrentImageContext()!
        UIGraphicsEndImageContext()
        
        hideToolBar(false)
        
        return memedImage
    }
    private func hideToolBar(_ hide: Bool) {
        navigationController?.navigationBar.isHidden = hide
        BottomBar.isHidden = hide
        view.backgroundColor = hide ? .clear : .black
    }
    
    @IBAction func cancel(_ sender: Any) {
        Top.text = "TOP"
        Botttom.text = "BOTTOM"
        imageView.image = nil
        share.isEnabled = false
    }
    
}


